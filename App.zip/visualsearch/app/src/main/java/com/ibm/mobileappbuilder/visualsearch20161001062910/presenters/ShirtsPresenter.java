
package com.ibm.mobileappbuilder.visualsearch20161001062910.presenters;

import com.ibm.mobileappbuilder.visualsearch20161001062910.R;
import com.ibm.mobileappbuilder.visualsearch20161001062910.ds.ShirtsDSItem;

import java.util.List;

import ibmmobileappbuilder.ds.CrudDatasource;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.mvp.presenter.BasePresenter;
import ibmmobileappbuilder.mvp.presenter.ListCrudPresenter;
import ibmmobileappbuilder.mvp.view.CrudListView;

public class ShirtsPresenter extends BasePresenter implements ListCrudPresenter<ShirtsDSItem>,
      Datasource.Listener<ShirtsDSItem>{

    private final CrudDatasource<ShirtsDSItem> crudDatasource;
    private final CrudListView<ShirtsDSItem> view;

    public ShirtsPresenter(CrudDatasource<ShirtsDSItem> crudDatasource,
                                         CrudListView<ShirtsDSItem> view) {
       this.crudDatasource = crudDatasource;
       this.view = view;
    }

    @Override
    public void deleteItem(ShirtsDSItem item) {
        crudDatasource.deleteItem(item, this);
    }

    @Override
    public void deleteItems(List<ShirtsDSItem> items) {
        crudDatasource.deleteItems(items, this);
    }

    @Override
    public void addForm() {
        view.showAdd();
    }

    @Override
    public void editForm(ShirtsDSItem item, int position) {
        view.showEdit(item, position);
    }

    @Override
    public void detail(ShirtsDSItem item, int position) {
        view.showDetail(item, position);
    }

    @Override
    public void onSuccess(ShirtsDSItem item) {
                view.showMessage(R.string.items_deleted);
        view.refresh();
    }

    @Override
    public void onFailure(Exception e) {
        view.showMessage(R.string.error_data_generic);
    }

}

