

package com.ibm.mobileappbuilder.visualsearch20161001062910.ds;

import android.content.Context;

import java.net.URL;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.restds.AppNowDatasource;
import ibmmobileappbuilder.util.StringUtils;
import ibmmobileappbuilder.ds.restds.TypedByteArrayUtils;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

/**
 * "ItemsDS" data source. (e37eb8dc-6eb2-4635-8592-5eb9696050e3)
 */
public class ItemsDS extends AppNowDatasource<ItemsDSItem>{

    // default page size
    private static final int PAGE_SIZE = 20;

    private ItemsDSService service;

    public static ItemsDS getInstance(SearchOptions searchOptions){
        return new ItemsDS(searchOptions);
    }

    private ItemsDS(SearchOptions searchOptions) {
        super(searchOptions);
        this.service = ItemsDSService.getInstance();
    }

    @Override
    public void getItem(String id, final Listener<ItemsDSItem> listener) {
        if ("0".equals(id)) {
                        getItems(new Listener<List<ItemsDSItem>>() {
                @Override
                public void onSuccess(List<ItemsDSItem> items) {
                    if(items != null && items.size() > 0) {
                        listener.onSuccess(items.get(0));
                    } else {
                        listener.onSuccess(new ItemsDSItem());
                    }
                }

                @Override
                public void onFailure(Exception e) {
                    listener.onFailure(e);
                }
            });
        } else {
                      service.getServiceProxy().getItemsDSItemById(id, new Callback<ItemsDSItem>() {
                @Override
                public void success(ItemsDSItem result, Response response) {
                                        listener.onSuccess(result);
                }

                @Override
                public void failure(RetrofitError error) {
                                        listener.onFailure(error);
                }
            });
        }
    }

    @Override
    public void getItems(final Listener<List<ItemsDSItem>> listener) {
        getItems(0, listener);
    }

    @Override
    public void getItems(int pagenum, final Listener<List<ItemsDSItem>> listener) {
        String conditions = getConditions(searchOptions, getSearchableFields());
        int skipNum = pagenum * PAGE_SIZE;
        String skip = skipNum == 0 ? null : String.valueOf(skipNum);
        String limit = PAGE_SIZE == 0 ? null: String.valueOf(PAGE_SIZE);
        String sort = getSort(searchOptions);
                service.getServiceProxy().queryItemsDSItem(
                skip,
                limit,
                conditions,
                sort,
                null,
                null,
                new Callback<List<ItemsDSItem>>() {
            @Override
            public void success(List<ItemsDSItem> result, Response response) {
                                listener.onSuccess(result);
            }

            @Override
            public void failure(RetrofitError error) {
                                listener.onFailure(error);
            }
        });
    }

    private String[] getSearchableFields() {
        return new String[]{"name", "text2", "text3"};
    }

    // Pagination

    @Override
    public int getPageSize(){
        return PAGE_SIZE;
    }

    @Override
    public void getUniqueValuesFor(String searchStr, final Listener<List<String>> listener) {
        String conditions = getConditions(searchOptions, getSearchableFields());
                service.getServiceProxy().distinct(searchStr, conditions, new Callback<List<String>>() {
             @Override
             public void success(List<String> result, Response response) {
                                  result.removeAll(Collections.<String>singleton(null));
                 listener.onSuccess(result);
             }

             @Override
             public void failure(RetrofitError error) {
                                  listener.onFailure(error);
             }
        });
    }

    @Override
    public URL getImageUrl(String path) {
        return service.getImageUrl(path);
    }

    @Override
    public void create(ItemsDSItem item, Listener<ItemsDSItem> listener) {
                    
        if(item.pictureUri != null){
            service.getServiceProxy().createItemsDSItem(item,
                TypedByteArrayUtils.fromUri(item.pictureUri),
                callbackFor(listener));
        }
        else
            service.getServiceProxy().createItemsDSItem(item, callbackFor(listener));
        
    }

    private Callback<ItemsDSItem> callbackFor(final Listener<ItemsDSItem> listener) {
      return new Callback<ItemsDSItem>() {
          @Override
          public void success(ItemsDSItem item, Response response) {
                            listener.onSuccess(item);
          }

          @Override
          public void failure(RetrofitError error) {
                            listener.onFailure(error);
          }
      };
    }

    @Override
    public void updateItem(ItemsDSItem item, Listener<ItemsDSItem> listener) {
                    
        if(item.pictureUri != null){
            service.getServiceProxy().updateItemsDSItem(item.getIdentifiableId(),
                item,
                TypedByteArrayUtils.fromUri(item.pictureUri),
                callbackFor(listener));
        }
        else
            service.getServiceProxy().updateItemsDSItem(item.getIdentifiableId(), item, callbackFor(listener));
        
    }

    @Override
    public void deleteItem(ItemsDSItem item, final Listener<ItemsDSItem> listener) {
                service.getServiceProxy().deleteItemsDSItemById(item.getIdentifiableId(), new Callback<ItemsDSItem>() {
            @Override
            public void success(ItemsDSItem result, Response response) {
                                listener.onSuccess(result);
            }

            @Override
            public void failure(RetrofitError error) {
                                listener.onFailure(error);
            }
        });
    }

    @Override
    public void deleteItems(List<ItemsDSItem> items, final Listener<ItemsDSItem> listener) {
                service.getServiceProxy().deleteByIds(collectIds(items), new Callback<List<ItemsDSItem>>() {
            @Override
            public void success(List<ItemsDSItem> item, Response response) {
                                listener.onSuccess(null);
            }

            @Override
            public void failure(RetrofitError error) {
                                listener.onFailure(error);
            }
        });
    }

    protected List<String> collectIds(List<ItemsDSItem> items){
        List<String> ids = new ArrayList<>();
        for(ItemsDSItem item: items){
            ids.add(item.getIdentifiableId());
        }
        return ids;
    }

}

