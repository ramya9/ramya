
package com.ibm.mobileappbuilder.visualsearch20161001062910.ds;
import java.util.List;
import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Query;
import retrofit.http.POST;
import retrofit.http.Body;
import retrofit.http.DELETE;
import retrofit.http.Path;
import retrofit.http.PUT;
import retrofit.mime.TypedByteArray;
import retrofit.http.Part;
import retrofit.http.Multipart;

public interface ShoesDSServiceRest{

	@GET("/app/57ef583957acb00300065679/r/shoesDS")
	void queryShoesDSItem(
		@Query("skip") String skip,
		@Query("limit") String limit,
		@Query("conditions") String conditions,
		@Query("sort") String sort,
		@Query("select") String select,
		@Query("populate") String populate,
		Callback<List<ShoesDSItem>> cb);

	@GET("/app/57ef583957acb00300065679/r/shoesDS/{id}")
	void getShoesDSItemById(@Path("id") String id, Callback<ShoesDSItem> cb);

	@DELETE("/app/57ef583957acb00300065679/r/shoesDS/{id}")
  void deleteShoesDSItemById(@Path("id") String id, Callback<ShoesDSItem> cb);

  @POST("/app/57ef583957acb00300065679/r/shoesDS/deleteByIds")
  void deleteByIds(@Body List<String> ids, Callback<List<ShoesDSItem>> cb);

  @POST("/app/57ef583957acb00300065679/r/shoesDS")
  void createShoesDSItem(@Body ShoesDSItem item, Callback<ShoesDSItem> cb);

  @PUT("/app/57ef583957acb00300065679/r/shoesDS/{id}")
  void updateShoesDSItem(@Path("id") String id, @Body ShoesDSItem item, Callback<ShoesDSItem> cb);

  @GET("/app/57ef583957acb00300065679/r/shoesDS")
  void distinct(
        @Query("distinct") String colName,
        @Query("conditions") String conditions,
        Callback<List<String>> cb);
    
    @Multipart
    @POST("/app/57ef583957acb00300065679/r/shoesDS")
    void createShoesDSItem(
        @Part("data") ShoesDSItem item,
        @Part("picture") TypedByteArray picture,
        Callback<ShoesDSItem> cb);
    
    @Multipart
    @PUT("/app/57ef583957acb00300065679/r/shoesDS/{id}")
    void updateShoesDSItem(
        @Path("id") String id,
        @Part("data") ShoesDSItem item,
        @Part("picture") TypedByteArray picture,
        Callback<ShoesDSItem> cb);
}

