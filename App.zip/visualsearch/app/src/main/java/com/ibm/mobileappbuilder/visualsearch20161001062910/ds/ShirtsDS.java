

package com.ibm.mobileappbuilder.visualsearch20161001062910.ds;

import android.content.Context;

import java.net.URL;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.restds.AppNowDatasource;
import ibmmobileappbuilder.util.StringUtils;
import ibmmobileappbuilder.ds.restds.TypedByteArrayUtils;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

/**
 * "ShirtsDS" data source. (e37eb8dc-6eb2-4635-8592-5eb9696050e3)
 */
public class ShirtsDS extends AppNowDatasource<ShirtsDSItem>{

    // default page size
    private static final int PAGE_SIZE = 20;

    private ShirtsDSService service;

    public static ShirtsDS getInstance(SearchOptions searchOptions){
        return new ShirtsDS(searchOptions);
    }

    private ShirtsDS(SearchOptions searchOptions) {
        super(searchOptions);
        this.service = ShirtsDSService.getInstance();
    }

    @Override
    public void getItem(String id, final Listener<ShirtsDSItem> listener) {
        if ("0".equals(id)) {
                        getItems(new Listener<List<ShirtsDSItem>>() {
                @Override
                public void onSuccess(List<ShirtsDSItem> items) {
                    if(items != null && items.size() > 0) {
                        listener.onSuccess(items.get(0));
                    } else {
                        listener.onSuccess(new ShirtsDSItem());
                    }
                }

                @Override
                public void onFailure(Exception e) {
                    listener.onFailure(e);
                }
            });
        } else {
                      service.getServiceProxy().getShirtsDSItemById(id, new Callback<ShirtsDSItem>() {
                @Override
                public void success(ShirtsDSItem result, Response response) {
                                        listener.onSuccess(result);
                }

                @Override
                public void failure(RetrofitError error) {
                                        listener.onFailure(error);
                }
            });
        }
    }

    @Override
    public void getItems(final Listener<List<ShirtsDSItem>> listener) {
        getItems(0, listener);
    }

    @Override
    public void getItems(int pagenum, final Listener<List<ShirtsDSItem>> listener) {
        String conditions = getConditions(searchOptions, getSearchableFields());
        int skipNum = pagenum * PAGE_SIZE;
        String skip = skipNum == 0 ? null : String.valueOf(skipNum);
        String limit = PAGE_SIZE == 0 ? null: String.valueOf(PAGE_SIZE);
        String sort = getSort(searchOptions);
                service.getServiceProxy().queryShirtsDSItem(
                skip,
                limit,
                conditions,
                sort,
                null,
                null,
                new Callback<List<ShirtsDSItem>>() {
            @Override
            public void success(List<ShirtsDSItem> result, Response response) {
                                listener.onSuccess(result);
            }

            @Override
            public void failure(RetrofitError error) {
                                listener.onFailure(error);
            }
        });
    }

    private String[] getSearchableFields() {
        return new String[]{"text1", "text2", "text3"};
    }

    // Pagination

    @Override
    public int getPageSize(){
        return PAGE_SIZE;
    }

    @Override
    public void getUniqueValuesFor(String searchStr, final Listener<List<String>> listener) {
        String conditions = getConditions(searchOptions, getSearchableFields());
                service.getServiceProxy().distinct(searchStr, conditions, new Callback<List<String>>() {
             @Override
             public void success(List<String> result, Response response) {
                                  result.removeAll(Collections.<String>singleton(null));
                 listener.onSuccess(result);
             }

             @Override
             public void failure(RetrofitError error) {
                                  listener.onFailure(error);
             }
        });
    }

    @Override
    public URL getImageUrl(String path) {
        return service.getImageUrl(path);
    }

    @Override
    public void create(ShirtsDSItem item, Listener<ShirtsDSItem> listener) {
                    
        if(item.pictureUri != null){
            service.getServiceProxy().createShirtsDSItem(item,
                TypedByteArrayUtils.fromUri(item.pictureUri),
                callbackFor(listener));
        }
        else
            service.getServiceProxy().createShirtsDSItem(item, callbackFor(listener));
        
    }

    private Callback<ShirtsDSItem> callbackFor(final Listener<ShirtsDSItem> listener) {
      return new Callback<ShirtsDSItem>() {
          @Override
          public void success(ShirtsDSItem item, Response response) {
                            listener.onSuccess(item);
          }

          @Override
          public void failure(RetrofitError error) {
                            listener.onFailure(error);
          }
      };
    }

    @Override
    public void updateItem(ShirtsDSItem item, Listener<ShirtsDSItem> listener) {
                    
        if(item.pictureUri != null){
            service.getServiceProxy().updateShirtsDSItem(item.getIdentifiableId(),
                item,
                TypedByteArrayUtils.fromUri(item.pictureUri),
                callbackFor(listener));
        }
        else
            service.getServiceProxy().updateShirtsDSItem(item.getIdentifiableId(), item, callbackFor(listener));
        
    }

    @Override
    public void deleteItem(ShirtsDSItem item, final Listener<ShirtsDSItem> listener) {
                service.getServiceProxy().deleteShirtsDSItemById(item.getIdentifiableId(), new Callback<ShirtsDSItem>() {
            @Override
            public void success(ShirtsDSItem result, Response response) {
                                listener.onSuccess(result);
            }

            @Override
            public void failure(RetrofitError error) {
                                listener.onFailure(error);
            }
        });
    }

    @Override
    public void deleteItems(List<ShirtsDSItem> items, final Listener<ShirtsDSItem> listener) {
                service.getServiceProxy().deleteByIds(collectIds(items), new Callback<List<ShirtsDSItem>>() {
            @Override
            public void success(List<ShirtsDSItem> item, Response response) {
                                listener.onSuccess(null);
            }

            @Override
            public void failure(RetrofitError error) {
                                listener.onFailure(error);
            }
        });
    }

    protected List<String> collectIds(List<ShirtsDSItem> items){
        List<String> ids = new ArrayList<>();
        for(ShirtsDSItem item: items){
            ids.add(item.getIdentifiableId());
        }
        return ids;
    }

}

