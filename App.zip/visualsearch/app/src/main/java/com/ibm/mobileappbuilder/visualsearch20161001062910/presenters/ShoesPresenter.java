
package com.ibm.mobileappbuilder.visualsearch20161001062910.presenters;

import com.ibm.mobileappbuilder.visualsearch20161001062910.R;
import com.ibm.mobileappbuilder.visualsearch20161001062910.ds.ShoesDSItem;

import java.util.List;

import ibmmobileappbuilder.ds.CrudDatasource;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.mvp.presenter.BasePresenter;
import ibmmobileappbuilder.mvp.presenter.ListCrudPresenter;
import ibmmobileappbuilder.mvp.view.CrudListView;

public class ShoesPresenter extends BasePresenter implements ListCrudPresenter<ShoesDSItem>,
      Datasource.Listener<ShoesDSItem>{

    private final CrudDatasource<ShoesDSItem> crudDatasource;
    private final CrudListView<ShoesDSItem> view;

    public ShoesPresenter(CrudDatasource<ShoesDSItem> crudDatasource,
                                         CrudListView<ShoesDSItem> view) {
       this.crudDatasource = crudDatasource;
       this.view = view;
    }

    @Override
    public void deleteItem(ShoesDSItem item) {
        crudDatasource.deleteItem(item, this);
    }

    @Override
    public void deleteItems(List<ShoesDSItem> items) {
        crudDatasource.deleteItems(items, this);
    }

    @Override
    public void addForm() {
        view.showAdd();
    }

    @Override
    public void editForm(ShoesDSItem item, int position) {
        view.showEdit(item, position);
    }

    @Override
    public void detail(ShoesDSItem item, int position) {
        view.showDetail(item, position);
    }

    @Override
    public void onSuccess(ShoesDSItem item) {
                view.showMessage(R.string.items_deleted);
        view.refresh();
    }

    @Override
    public void onFailure(Exception e) {
        view.showMessage(R.string.error_data_generic);
    }

}

