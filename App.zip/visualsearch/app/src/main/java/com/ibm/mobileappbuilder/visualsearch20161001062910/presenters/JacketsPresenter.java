
package com.ibm.mobileappbuilder.visualsearch20161001062910.presenters;

import com.ibm.mobileappbuilder.visualsearch20161001062910.R;
import com.ibm.mobileappbuilder.visualsearch20161001062910.ds.ItemsDSItem;

import java.util.List;

import ibmmobileappbuilder.ds.CrudDatasource;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.mvp.presenter.BasePresenter;
import ibmmobileappbuilder.mvp.presenter.ListCrudPresenter;
import ibmmobileappbuilder.mvp.view.CrudListView;

public class JacketsPresenter extends BasePresenter implements ListCrudPresenter<ItemsDSItem>,
      Datasource.Listener<ItemsDSItem>{

    private final CrudDatasource<ItemsDSItem> crudDatasource;
    private final CrudListView<ItemsDSItem> view;

    public JacketsPresenter(CrudDatasource<ItemsDSItem> crudDatasource,
                                         CrudListView<ItemsDSItem> view) {
       this.crudDatasource = crudDatasource;
       this.view = view;
    }

    @Override
    public void deleteItem(ItemsDSItem item) {
        crudDatasource.deleteItem(item, this);
    }

    @Override
    public void deleteItems(List<ItemsDSItem> items) {
        crudDatasource.deleteItems(items, this);
    }

    @Override
    public void addForm() {
        view.showAdd();
    }

    @Override
    public void editForm(ItemsDSItem item, int position) {
        view.showEdit(item, position);
    }

    @Override
    public void detail(ItemsDSItem item, int position) {
        view.showDetail(item, position);
    }

    @Override
    public void onSuccess(ItemsDSItem item) {
                view.showMessage(R.string.items_deleted);
        view.refresh();
    }

    @Override
    public void onFailure(Exception e) {
        view.showMessage(R.string.error_data_generic);
    }

}

