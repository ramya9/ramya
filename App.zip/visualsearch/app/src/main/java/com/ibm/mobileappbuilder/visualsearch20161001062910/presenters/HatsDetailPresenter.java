
package com.ibm.mobileappbuilder.visualsearch20161001062910.presenters;

import com.ibm.mobileappbuilder.visualsearch20161001062910.R;
import com.ibm.mobileappbuilder.visualsearch20161001062910.ds.HatsDSItem;

import ibmmobileappbuilder.ds.CrudDatasource;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.mvp.presenter.BasePresenter;
import ibmmobileappbuilder.mvp.presenter.DetailCrudPresenter;
import ibmmobileappbuilder.mvp.view.DetailView;

public class HatsDetailPresenter extends BasePresenter implements DetailCrudPresenter<HatsDSItem>,
      Datasource.Listener<HatsDSItem> {

    private final CrudDatasource<HatsDSItem> datasource;
    private final DetailView view;

    public HatsDetailPresenter(CrudDatasource<HatsDSItem> datasource, DetailView view){
        this.datasource = datasource;
        this.view = view;
    }

    @Override
    public void deleteItem(HatsDSItem item) {
        datasource.deleteItem(item, this);
    }

    @Override
    public void editForm(HatsDSItem item) {
        view.navigateToEditForm();
    }

    @Override
    public void onSuccess(HatsDSItem item) {
                view.showMessage(R.string.item_deleted, true);
        view.close(true);
    }

    @Override
    public void onFailure(Exception e) {
        view.showMessage(R.string.error_data_generic, true);
    }
}

