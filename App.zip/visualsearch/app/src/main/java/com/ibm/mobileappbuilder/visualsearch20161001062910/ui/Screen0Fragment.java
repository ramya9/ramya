

package com.ibm.mobileappbuilder.visualsearch20161001062910.ui;

import android.os.Bundle;

import com.ibm.mobileappbuilder.visualsearch20161001062910.R;

import java.util.ArrayList;
import java.util.List;

import ibmmobileappbuilder.MenuItem;

import ibmmobileappbuilder.actions.StartActivityAction;
import ibmmobileappbuilder.util.Constants;

/**
 * Screen0Fragment menu fragment.
 */
public class Screen0Fragment extends ibmmobileappbuilder.ui.MenuFragment {

    /**
     * Default constructor
     */
    public Screen0Fragment(){
        super();
    }

    // Factory method
    public static Screen0Fragment newInstance(Bundle args) {
        Screen0Fragment fragment = new Screen0Fragment();

        fragment.setArguments(args);
        return fragment;
    }

    @Override
      public void onCreate(Bundle savedInstanceState) {
          super.onCreate(savedInstanceState);
                }

    // Menu Fragment interface
    @Override
    public List<MenuItem> getMenuItems() {
        ArrayList<MenuItem> items = new ArrayList<MenuItem>();
        items.add(new MenuItem()
            .setLabel("Jackets")
            .setIcon(R.drawable.png_defaultmenuicon)
            .setAction(new StartActivityAction(JacketsActivity.class, Constants.DETAIL))
        );
        items.add(new MenuItem()
            .setLabel("hats")
            .setIcon(R.drawable.png_defaultmenuicon)
            .setAction(new StartActivityAction(HatsActivity.class, Constants.DETAIL))
        );
        items.add(new MenuItem()
            .setLabel("shirts")
            .setIcon(R.drawable.png_defaultmenuicon)
            .setAction(new StartActivityAction(ShirtsActivity.class, Constants.DETAIL))
        );
        items.add(new MenuItem()
            .setLabel("shoes")
            .setIcon(R.drawable.png_defaultmenuicon)
            .setAction(new StartActivityAction(ShoesActivity.class, Constants.DETAIL))
        );
        return items;
    }

    @Override
    public int getLayout() {
        return R.layout.fragment_list;
    }

    @Override
    public int getItemLayout() {
        return R.layout.screen0_item;
    }
}

