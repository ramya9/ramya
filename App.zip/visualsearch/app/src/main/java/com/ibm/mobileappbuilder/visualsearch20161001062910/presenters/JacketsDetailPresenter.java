
package com.ibm.mobileappbuilder.visualsearch20161001062910.presenters;

import com.ibm.mobileappbuilder.visualsearch20161001062910.R;
import com.ibm.mobileappbuilder.visualsearch20161001062910.ds.ItemsDSItem;

import ibmmobileappbuilder.ds.CrudDatasource;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.mvp.presenter.BasePresenter;
import ibmmobileappbuilder.mvp.presenter.DetailCrudPresenter;
import ibmmobileappbuilder.mvp.view.DetailView;

public class JacketsDetailPresenter extends BasePresenter implements DetailCrudPresenter<ItemsDSItem>,
      Datasource.Listener<ItemsDSItem> {

    private final CrudDatasource<ItemsDSItem> datasource;
    private final DetailView view;

    public JacketsDetailPresenter(CrudDatasource<ItemsDSItem> datasource, DetailView view){
        this.datasource = datasource;
        this.view = view;
    }

    @Override
    public void deleteItem(ItemsDSItem item) {
        datasource.deleteItem(item, this);
    }

    @Override
    public void editForm(ItemsDSItem item) {
        view.navigateToEditForm();
    }

    @Override
    public void onSuccess(ItemsDSItem item) {
                view.showMessage(R.string.item_deleted, true);
        view.close(true);
    }

    @Override
    public void onFailure(Exception e) {
        view.showMessage(R.string.error_data_generic, true);
    }
}

