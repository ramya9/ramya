
package com.ibm.mobileappbuilder.visualsearch20161001062910.ds;
import java.net.URL;
import com.ibm.mobileappbuilder.visualsearch20161001062910.R;
import ibmmobileappbuilder.ds.RestService;
import ibmmobileappbuilder.util.StringUtils;

/**
 * "ShirtsDSService" REST Service implementation
 */
public class ShirtsDSService extends RestService<ShirtsDSServiceRest>{

    public static ShirtsDSService getInstance(){
          return new ShirtsDSService();
    }

    private ShirtsDSService() {
        super(ShirtsDSServiceRest.class);

    }

    @Override
    public String getServerUrl() {
        return "https://ibm-pods.buildup.io";
    }

    @Override
    protected String getApiKey() {
        return "v4TjhVd4";
    }

    @Override
    public URL getImageUrl(String path){
        return StringUtils.parseUrl("https://ibm-pods.buildup.io/app/57ef583957acb00300065679",
                path,
                "apikey=v4TjhVd4");
    }

}

