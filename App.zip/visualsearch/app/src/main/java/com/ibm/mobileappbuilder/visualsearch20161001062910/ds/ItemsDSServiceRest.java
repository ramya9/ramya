
package com.ibm.mobileappbuilder.visualsearch20161001062910.ds;
import java.util.List;
import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Query;
import retrofit.http.POST;
import retrofit.http.Body;
import retrofit.http.DELETE;
import retrofit.http.Path;
import retrofit.http.PUT;
import retrofit.mime.TypedByteArray;
import retrofit.http.Part;
import retrofit.http.Multipart;

public interface ItemsDSServiceRest{

	@GET("/app/57ef583957acb00300065679/r/itemsDS")
	void queryItemsDSItem(
		@Query("skip") String skip,
		@Query("limit") String limit,
		@Query("conditions") String conditions,
		@Query("sort") String sort,
		@Query("select") String select,
		@Query("populate") String populate,
		Callback<List<ItemsDSItem>> cb);

	@GET("/app/57ef583957acb00300065679/r/itemsDS/{id}")
	void getItemsDSItemById(@Path("id") String id, Callback<ItemsDSItem> cb);

	@DELETE("/app/57ef583957acb00300065679/r/itemsDS/{id}")
  void deleteItemsDSItemById(@Path("id") String id, Callback<ItemsDSItem> cb);

  @POST("/app/57ef583957acb00300065679/r/itemsDS/deleteByIds")
  void deleteByIds(@Body List<String> ids, Callback<List<ItemsDSItem>> cb);

  @POST("/app/57ef583957acb00300065679/r/itemsDS")
  void createItemsDSItem(@Body ItemsDSItem item, Callback<ItemsDSItem> cb);

  @PUT("/app/57ef583957acb00300065679/r/itemsDS/{id}")
  void updateItemsDSItem(@Path("id") String id, @Body ItemsDSItem item, Callback<ItemsDSItem> cb);

  @GET("/app/57ef583957acb00300065679/r/itemsDS")
  void distinct(
        @Query("distinct") String colName,
        @Query("conditions") String conditions,
        Callback<List<String>> cb);
    
    @Multipart
    @POST("/app/57ef583957acb00300065679/r/itemsDS")
    void createItemsDSItem(
        @Part("data") ItemsDSItem item,
        @Part("picture") TypedByteArray picture,
        Callback<ItemsDSItem> cb);
    
    @Multipart
    @PUT("/app/57ef583957acb00300065679/r/itemsDS/{id}")
    void updateItemsDSItem(
        @Path("id") String id,
        @Part("data") ItemsDSItem item,
        @Part("picture") TypedByteArray picture,
        Callback<ItemsDSItem> cb);
}

