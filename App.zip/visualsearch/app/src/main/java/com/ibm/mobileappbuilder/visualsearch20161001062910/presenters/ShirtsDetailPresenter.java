
package com.ibm.mobileappbuilder.visualsearch20161001062910.presenters;

import com.ibm.mobileappbuilder.visualsearch20161001062910.R;
import com.ibm.mobileappbuilder.visualsearch20161001062910.ds.ShirtsDSItem;

import ibmmobileappbuilder.ds.CrudDatasource;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.mvp.presenter.BasePresenter;
import ibmmobileappbuilder.mvp.presenter.DetailCrudPresenter;
import ibmmobileappbuilder.mvp.view.DetailView;

public class ShirtsDetailPresenter extends BasePresenter implements DetailCrudPresenter<ShirtsDSItem>,
      Datasource.Listener<ShirtsDSItem> {

    private final CrudDatasource<ShirtsDSItem> datasource;
    private final DetailView view;

    public ShirtsDetailPresenter(CrudDatasource<ShirtsDSItem> datasource, DetailView view){
        this.datasource = datasource;
        this.view = view;
    }

    @Override
    public void deleteItem(ShirtsDSItem item) {
        datasource.deleteItem(item, this);
    }

    @Override
    public void editForm(ShirtsDSItem item) {
        view.navigateToEditForm();
    }

    @Override
    public void onSuccess(ShirtsDSItem item) {
                view.showMessage(R.string.item_deleted, true);
        view.close(true);
    }

    @Override
    public void onFailure(Exception e) {
        view.showMessage(R.string.error_data_generic, true);
    }
}

