
package com.ibm.mobileappbuilder.visualsearch20161001062910.ds;
import java.util.List;
import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Query;
import retrofit.http.POST;
import retrofit.http.Body;
import retrofit.http.DELETE;
import retrofit.http.Path;
import retrofit.http.PUT;
import retrofit.mime.TypedByteArray;
import retrofit.http.Part;
import retrofit.http.Multipart;

public interface ShirtsDSServiceRest{

	@GET("/app/57ef583957acb00300065679/r/shirtsDS")
	void queryShirtsDSItem(
		@Query("skip") String skip,
		@Query("limit") String limit,
		@Query("conditions") String conditions,
		@Query("sort") String sort,
		@Query("select") String select,
		@Query("populate") String populate,
		Callback<List<ShirtsDSItem>> cb);

	@GET("/app/57ef583957acb00300065679/r/shirtsDS/{id}")
	void getShirtsDSItemById(@Path("id") String id, Callback<ShirtsDSItem> cb);

	@DELETE("/app/57ef583957acb00300065679/r/shirtsDS/{id}")
  void deleteShirtsDSItemById(@Path("id") String id, Callback<ShirtsDSItem> cb);

  @POST("/app/57ef583957acb00300065679/r/shirtsDS/deleteByIds")
  void deleteByIds(@Body List<String> ids, Callback<List<ShirtsDSItem>> cb);

  @POST("/app/57ef583957acb00300065679/r/shirtsDS")
  void createShirtsDSItem(@Body ShirtsDSItem item, Callback<ShirtsDSItem> cb);

  @PUT("/app/57ef583957acb00300065679/r/shirtsDS/{id}")
  void updateShirtsDSItem(@Path("id") String id, @Body ShirtsDSItem item, Callback<ShirtsDSItem> cb);

  @GET("/app/57ef583957acb00300065679/r/shirtsDS")
  void distinct(
        @Query("distinct") String colName,
        @Query("conditions") String conditions,
        Callback<List<String>> cb);
    
    @Multipart
    @POST("/app/57ef583957acb00300065679/r/shirtsDS")
    void createShirtsDSItem(
        @Part("data") ShirtsDSItem item,
        @Part("picture") TypedByteArray picture,
        Callback<ShirtsDSItem> cb);
    
    @Multipart
    @PUT("/app/57ef583957acb00300065679/r/shirtsDS/{id}")
    void updateShirtsDSItem(
        @Path("id") String id,
        @Part("data") ShirtsDSItem item,
        @Part("picture") TypedByteArray picture,
        Callback<ShirtsDSItem> cb);
}

