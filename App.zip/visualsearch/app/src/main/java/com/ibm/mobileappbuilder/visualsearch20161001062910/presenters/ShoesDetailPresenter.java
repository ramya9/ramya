
package com.ibm.mobileappbuilder.visualsearch20161001062910.presenters;

import com.ibm.mobileappbuilder.visualsearch20161001062910.R;
import com.ibm.mobileappbuilder.visualsearch20161001062910.ds.ShoesDSItem;

import ibmmobileappbuilder.ds.CrudDatasource;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.mvp.presenter.BasePresenter;
import ibmmobileappbuilder.mvp.presenter.DetailCrudPresenter;
import ibmmobileappbuilder.mvp.view.DetailView;

public class ShoesDetailPresenter extends BasePresenter implements DetailCrudPresenter<ShoesDSItem>,
      Datasource.Listener<ShoesDSItem> {

    private final CrudDatasource<ShoesDSItem> datasource;
    private final DetailView view;

    public ShoesDetailPresenter(CrudDatasource<ShoesDSItem> datasource, DetailView view){
        this.datasource = datasource;
        this.view = view;
    }

    @Override
    public void deleteItem(ShoesDSItem item) {
        datasource.deleteItem(item, this);
    }

    @Override
    public void editForm(ShoesDSItem item) {
        view.navigateToEditForm();
    }

    @Override
    public void onSuccess(ShoesDSItem item) {
                view.showMessage(R.string.item_deleted, true);
        view.close(true);
    }

    @Override
    public void onFailure(Exception e) {
        view.showMessage(R.string.error_data_generic, true);
    }
}

